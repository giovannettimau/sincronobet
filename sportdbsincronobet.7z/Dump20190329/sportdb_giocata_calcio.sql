-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: sportdb
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `giocata_calcio`
--

DROP TABLE IF EXISTS `giocata_calcio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `giocata_calcio` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL,
  `calcio_id` int(11) DEFAULT NULL,
  `storico_giocate_id` int(11) DEFAULT NULL,
  `risultato_scommesso` text,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `giocata_calcio`
--

LOCK TABLES `giocata_calcio` WRITE;
/*!40000 ALTER TABLE `giocata_calcio` DISABLE KEYS */;
INSERT INTO `giocata_calcio` VALUES (1,1,7,2,'1'),(2,1,8,2,'x'),(3,1,18,2,'1'),(4,2,1,3,'x'),(5,2,2,3,'x'),(6,2,3,3,'x'),(7,4,1,5,'x'),(8,4,2,5,'x'),(9,4,3,5,'x'),(10,5,1,6,'x'),(13,7,11,10,'x'),(18,11,14,16,'x'),(19,12,4,17,'1'),(20,12,14,17,'1'),(21,14,13,20,'2'),(22,14,15,20,'1'),(23,16,15,22,'x'),(24,19,4,25,'x'),(25,20,1,1,'1'),(26,20,2,1,'1'),(27,20,3,1,'1'),(28,20,4,1,'2'),(29,20,5,1,'x'),(30,20,6,1,'1'),(31,21,10,19,'x'),(32,21,16,19,'x'),(33,21,20,19,'2'),(34,23,4,13,'2'),(35,23,14,13,'2'),(36,25,11,8,'x'),(37,25,14,8,'x'),(38,26,8,28,'1'),(39,26,13,28,'1'),(40,26,18,28,'1'),(41,28,9,35,'1'),(42,29,2,37,'1'),(43,30,12,40,'2'),(44,31,15,36,'1'),(45,31,16,36,'2'),(46,31,17,36,'x'),(47,33,7,32,'x'),(48,35,1,30,'2'),(49,35,4,30,'2'),(50,35,5,30,'x'),(51,35,20,30,'1'),(52,35,21,30,'x'),(53,36,13,41,'1'),(54,37,8,43,'1'),(55,37,9,43,'1'),(56,37,13,43,'1'),(57,40,1,43,'1'),(58,40,2,43,'1'),(59,40,3,43,'2'),(60,40,4,43,'2'),(61,40,5,43,'2'),(62,40,6,43,'1'),(63,40,2,43,'1'),(64,40,1,43,'1'),(65,40,2,43,'1'),(66,40,3,43,'1'),(67,40,1,44,'1'),(68,40,3,44,'1'),(69,40,4,44,'1'),(70,40,5,44,'2'),(71,40,1,45,'1'),(72,40,2,45,'1'),(73,40,3,45,'1'),(74,40,4,45,'1'),(75,40,5,45,'1'),(76,40,1,46,'1'),(77,40,1,47,'1'),(78,40,2,47,'1'),(79,40,3,47,'1'),(80,40,1,49,'1'),(81,40,2,49,'1'),(82,40,3,49,'1'),(83,59,2,50,'x'),(84,59,3,50,'2'),(85,59,2,50,'x'),(86,40,9,61,'1'),(87,60,1,66,'1'),(88,60,2,66,'x'),(89,60,3,66,'1'),(90,60,1,67,'1'),(91,60,6,67,'2'),(92,60,15,67,'1'),(93,60,1,68,'1'),(94,40,1,70,'1'),(95,51,1,72,'1'),(96,51,2,72,'1'),(97,51,3,72,'1'),(98,40,6,77,'1'),(99,40,6,78,'1'),(100,40,6,84,'1'),(101,40,3,84,'x'),(102,40,3,89,'1'),(103,40,2,89,'x'),(104,40,8,89,'2'),(105,40,3,90,'1'),(106,40,2,90,'x'),(107,40,8,90,'2'),(108,40,1,92,'1'),(109,40,2,96,'1'),(110,40,1,96,'2'),(111,40,3,96,'x'),(112,40,10,96,'x'),(113,40,11,96,'1');
/*!40000 ALTER TABLE `giocata_calcio` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-29 14:25:11
