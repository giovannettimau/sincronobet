-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: sportdb
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `giocata_basket`
--

DROP TABLE IF EXISTS `giocata_basket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `giocata_basket` (
  `b_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL,
  `basket_id` int(11) DEFAULT NULL,
  `storico_giocate_id` int(11) DEFAULT NULL,
  `risultato_scommesso` text,
  PRIMARY KEY (`b_id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `giocata_basket`
--

LOCK TABLES `giocata_basket` WRITE;
/*!40000 ALTER TABLE `giocata_basket` DISABLE KEYS */;
INSERT INTO `giocata_basket` VALUES (1,1,20,26,'1'),(2,1,27,26,'1'),(3,2,3,3,'2'),(4,2,4,3,'2'),(5,2,5,3,'2'),(6,5,4,6,'2'),(7,9,3,12,'2'),(8,10,1,15,'1'),(9,20,2,1,'2'),(10,20,3,1,'1'),(11,20,4,1,'1'),(12,20,7,1,'2'),(13,24,1,9,'2'),(14,24,2,9,'1'),(15,24,3,9,'2'),(16,31,24,36,'2'),(17,31,26,36,'2'),(18,31,27,36,'2'),(19,33,2,32,'2'),(20,43,10,39,'2'),(21,44,9,42,'1'),(22,44,27,42,'2'),(23,45,9,27,'1'),(24,45,11,34,'2'),(25,50,19,31,'1'),(27,40,1,43,'1'),(28,40,1,47,'1'),(29,40,2,47,'1'),(30,40,3,47,'1'),(31,40,1,49,'1'),(32,40,2,49,'1'),(33,40,3,49,'1'),(34,40,1,51,'1'),(35,40,1,52,'1'),(36,40,1,53,'1'),(37,40,1,54,'1'),(38,40,6,55,'1'),(39,40,6,56,'1'),(40,40,1,56,'1'),(41,40,1,60,'1'),(42,40,21,61,'1'),(43,40,8,62,'1'),(44,40,8,63,'1'),(45,40,8,64,'1'),(46,60,1,65,'1'),(47,60,9,65,'2'),(48,60,19,65,'1'),(49,60,19,65,'2'),(50,60,1,68,'1'),(51,40,1,71,'1'),(52,40,9,75,'1'),(53,40,8,79,'1'),(54,40,6,80,'1'),(55,40,2,80,'2'),(56,40,9,85,'1'),(57,40,9,86,'1'),(58,40,2,88,'1'),(59,40,12,88,'2'),(60,40,9,91,'1'),(61,40,3,91,'1'),(62,40,7,91,'2'),(63,40,7,93,'1'),(64,40,9,93,'1'),(65,51,1,94,'1'),(66,51,12,94,'2'),(67,51,14,94,'1'),(68,40,8,95,'1'),(69,40,8,100,'2');
/*!40000 ALTER TABLE `giocata_basket` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-29 14:25:12
