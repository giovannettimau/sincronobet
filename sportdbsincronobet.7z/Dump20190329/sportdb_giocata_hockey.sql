-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: sportdb
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `giocata_hockey`
--

DROP TABLE IF EXISTS `giocata_hockey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `giocata_hockey` (
  `h_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL,
  `hockey_id` int(11) DEFAULT NULL,
  `storico_giocate_id` int(11) DEFAULT NULL,
  `risultato_scommesso` text,
  PRIMARY KEY (`h_id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `giocata_hockey`
--

LOCK TABLES `giocata_hockey` WRITE;
/*!40000 ALTER TABLE `giocata_hockey` DISABLE KEYS */;
INSERT INTO `giocata_hockey` VALUES (1,3,7,4,'1'),(2,3,8,4,'2'),(3,5,8,6,'2'),(7,13,5,18,'2'),(8,15,5,21,'2'),(9,17,1,23,'2'),(10,17,3,23,'1'),(11,17,5,23,'2'),(12,18,1,24,'1'),(13,18,3,24,'2'),(14,18,5,24,'1'),(15,20,1,1,'1'),(16,20,2,1,'2'),(17,22,1,14,'2'),(18,27,6,33,'2'),(19,30,2,40,'2'),(20,32,1,29,'1'),(21,32,6,29,'2'),(22,33,1,32,'2'),(23,37,8,43,'2'),(24,41,4,38,'2'),(25,41,8,38,'2'),(26,40,1,43,'1'),(27,40,1,47,'1'),(28,40,2,47,'1'),(29,40,3,47,'1'),(30,40,1,49,'1'),(31,40,2,49,'1'),(32,40,3,49,'1'),(33,40,4,49,'1'),(34,59,1,50,'2'),(35,59,2,50,'2'),(36,59,3,50,'2'),(37,40,8,51,'2'),(38,40,1,54,'1'),(39,40,3,54,'2'),(40,40,6,54,'1'),(41,40,7,57,'1'),(42,40,6,58,'1'),(43,40,7,59,'1'),(44,40,5,59,'1'),(45,40,7,60,'1'),(46,40,5,60,'1'),(47,40,1,61,'1'),(48,40,4,61,'2'),(49,40,7,61,'2'),(50,40,8,62,'1'),(51,40,8,63,'1'),(52,40,2,63,'1'),(53,40,8,64,'1'),(54,40,2,64,'1'),(55,60,1,66,'1'),(56,60,1,68,'1'),(57,40,4,69,'2'),(58,40,3,69,'1'),(59,51,8,73,'1'),(60,40,1,74,'1'),(61,40,1,76,'1'),(62,40,8,77,'1'),(63,40,8,78,'1'),(64,40,4,81,'1'),(65,40,4,82,'1'),(66,40,4,83,'1'),(67,40,1,87,'1'),(68,51,1,94,'1'),(69,40,1,95,'1'),(70,40,3,95,'2'),(71,40,8,95,'1'),(72,40,8,95,'2'),(73,40,8,98,'2'),(74,40,4,99,'1');
/*!40000 ALTER TABLE `giocata_hockey` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-29 14:25:10
