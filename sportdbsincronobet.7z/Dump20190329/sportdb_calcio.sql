-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: sportdb
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `calcio`
--

DROP TABLE IF EXISTS `calcio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `calcio` (
  `id` int(11) NOT NULL,
  `campionato` text,
  `squadra_1` text,
  `squadra_2` text,
  `p_1` int(11) DEFAULT NULL,
  `p_2` int(11) DEFAULT NULL,
  `risultato` text,
  `quota_1` double DEFAULT NULL,
  `quota_x` double DEFAULT NULL,
  `quota_2` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calcio`
--

LOCK TABLES `calcio` WRITE;
/*!40000 ALTER TABLE `calcio` DISABLE KEYS */;
INSERT INTO `calcio` VALUES (1,'Serie A','Verona','Benevento',1,0,'1',1.95,3.5,3.75),(2,'Serie A','Inter','AC Milan',3,2,'1',2.1,3.4,3.4),(3,'Serie A','Bologna','Spal',2,1,'1',1.8,3.3,4.75),(4,'Serie A','Cagliari','Genoa',2,3,'2',2.2,3.4,3.2),(5,'Serie A','Crotone','Torino',2,2,'x',5,3.5,1.73),(6,'Serie A','Sampdoria','Atalanta',3,1,'1',2.4,3.25,2.9),(7,'Serie A','Sassuolo','Chievo',0,0,'x',2.1,3.3,3.5),(8,'Serie A','Fiorentina','Udinese',2,1,'1',1.57,3.75,6),(9,'Serie A','AS Roma','Napoli',0,1,'2',2.6,3.3,2.63),(10,'Serie A','Juventus','Lazio',1,2,'2',1.44,4.33,7),(11,'Serie B','Entella','Empoli',2,3,'2',3.1,3.1,2.4),(12,'Serie B','Avellino','Salernitana',2,3,'2',2.25,3,3.5),(13,'Serie B','Ascoli','Venezia',3,3,'2',2.63,2.88,3),(14,'Serie B','Brescia','Novara',0,1,'2',2.3,3,3.4),(15,'Serie B','Carpi','Cesena',2,1,'1',1.91,3.1,4.5),(16,'Serie B','Cittadella','Cremonese',1,2,'2',2.05,3.1,4),(17,'Serie B','Frosinone','Palermo',0,0,'x',2.3,3,3.4),(18,'Serie B','Parma','Pescara',0,1,'2',2.15,3.3,3.4),(19,'Serie B','Pro Vercelli','Bari',2,2,'x',2.88,2.88,2.7),(20,'Serie B','Ternana','Spezia',4,2,'1',2.5,3,3),(21,'Serie B','Foggia','Perugia',2,1,'1',2.3,3.1,3.25);
/*!40000 ALTER TABLE `calcio` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-29 14:25:11
