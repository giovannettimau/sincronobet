-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: sportdb
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` text,
  `last_name` text,
  `email` text,
  `password` text,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (2,'Thomas','Strakosha','thomas.strakosha@sslazio.org','coppainfaccia'),(3,'Stefan','radu','stefan.radu@sslazio.org','coppainfaccia'),(4,'Patricio','Gabarron','patric@sslazio.org','coppainfaccia'),(5,'Lucas','Leiva','leiva@sslazio.org','coppainfaccia'),(6,'Ciro','Immobile','immobile@sslazio.org','coppainfaccia'),(7,'MARIA','MILLER','MARIA.MILLER@sakilacustomer.org','11'),(8,'Felipe','Caiceido','caiceido@sslazio.org','coppainfaccia'),(9,'MARGARET','MOORE','MARGARET.MOORE@sakilacustomer.org','13'),(10,'DOROTHY','TAYLOR','DOROTHY.TAYLOR@sakilacustomer.org','14'),(11,'LISA','ANDERSON','LISA.ANDERSON@sakilacustomer.org','15'),(12,'NANCY','THOMAS','NANCY.THOMAS@sakilacustomer.org','16'),(13,'KAREN','JACKSON','KAREN.JACKSON@sakilacustomer.org','17'),(14,'BETTY','WHITE','BETTY.WHITE@sakilacustomer.org','18'),(15,'HELEN','HARRIS','HELEN.HARRIS@sakilacustomer.org','19'),(16,'SANDRA','MARTIN','SANDRA.MARTIN@sakilacustomer.org','20'),(17,'DONNA','THOMPSON','DONNA.THOMPSON@sakilacustomer.org','21'),(18,'CAROL','GARCIA','CAROL.GARCIA@sakilacustomer.org','22'),(19,'RUTH','MARTINEZ','RUTH.MARTINEZ@sakilacustomer.org','23'),(20,'SHARON','ROBINSON','SHARON.ROBINSON@sakilacustomer.org','24'),(21,'MICHELLE','CLARK','MICHELLE.CLARK@sakilacustomer.org','25'),(22,'LAURA','RODRIGUEZ','LAURA.RODRIGUEZ@sakilacustomer.org','26'),(23,'SARAH','LEWIS','SARAH.LEWIS@sakilacustomer.org','27'),(24,'KIMBERLY','LEE','KIMBERLY.LEE@sakilacustomer.org','28'),(25,'DEBORAH','WALKER','DEBORAH.WALKER@sakilacustomer.org','29'),(26,'JESSICA','HALL','JESSICA.HALL@sakilacustomer.org','30'),(27,'SHIRLEY','ALLEN','SHIRLEY.ALLEN@sakilacustomer.org','31'),(28,'CYNTHIA','YOUNG','CYNTHIA.YOUNG@sakilacustomer.org','32'),(29,'ANGELA','HERNANDEZ','ANGELA.HERNANDEZ@sakilacustomer.org','33'),(30,'MELISSA','KING','MELISSA.KING@sakilacustomer.org','34'),(31,'BRENDA','WRIGHT','BRENDA.WRIGHT@sakilacustomer.org','35'),(32,'AMY','LOPEZ','AMY.LOPEZ@sakilacustomer.org','36'),(33,'ANNA','HILL','ANNA.HILL@sakilacustomer.org','37'),(34,'REBECCA','SCOTT','REBECCA.SCOTT@sakilacustomer.org','38'),(35,'VIRGINIA','GREEN','VIRGINIA.GREEN@sakilacustomer.org','39'),(36,'KATHLEEN','ADAMS','KATHLEEN.ADAMS@sakilacustomer.org','40'),(37,'PAMELA','BAKER','PAMELA.BAKER@sakilacustomer.org','41'),(38,'MARTHA','GONZALEZ','MARTHA.GONZALEZ@sakilacustomer.org','42'),(39,'DEBRA','NELSON','DEBRA.NELSON@sakilacustomer.org','43'),(40,'AMANDA','CARTER','AMANDA.CARTER@sakilacustomer.org','44'),(41,'STEPHANIE','MITCHELL','STEPHANIE.MITCHELL@sakilacustomer.org','45'),(42,'CAROLYN','PEREZ','CAROLYN.PEREZ@sakilacustomer.org','46'),(43,'CHRISTINE','ROBERTS','CHRISTINE.ROBERTS@sakilacustomer.org','47'),(44,'MARIE','TURNER','MARIE.TURNER@sakilacustomer.org','48'),(45,'JANET','PHILLIPS','JANET.PHILLIPS@sakilacustomer.org','49'),(46,'CATHERINE','CAMPBELL','CATHERINE.CAMPBELL@sakilacustomer.org','50'),(47,'FRANCES','PARKER','FRANCES.PARKER@sakilacustomer.org','51'),(48,'ANN','EVANS','ANN.EVANS@sakilacustomer.org','52'),(49,'JOYCE','EDWARDS','JOYCE.EDWARDS@sakilacustomer.org','53'),(50,'DIANE','COLLINS','diane.colle@gmail.com','54'),(51,'Luke','PeterSaint','lukepetersaint@gmail.com','vobinli'),(52,'Pietro','Sant\'Andrea�','pietro13@morandi.com','126gang');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-29 14:25:10
