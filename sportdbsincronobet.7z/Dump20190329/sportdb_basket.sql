-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: sportdb
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `basket`
--

DROP TABLE IF EXISTS `basket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `basket` (
  `id` int(11) NOT NULL,
  `campionato` text,
  `squadra_1` text,
  `squadra_2` text,
  `p_1` int(11) DEFAULT NULL,
  `p_2` int(11) DEFAULT NULL,
  `risultato` text,
  `quota_1` double DEFAULT NULL,
  `quota_2` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basket`
--

LOCK TABLES `basket` WRITE;
/*!40000 ALTER TABLE `basket` DISABLE KEYS */;
INSERT INTO `basket` VALUES (1,'NBA','Golden State Warriors','Miami Heat',120,118,'1',1.07,9.5),(2,'NBA','Atlanta Hawks','Orlando Magic',108,124,'2',2.2,1.71),(3,'NBA','Sacramento Kings','Phoenix Suns',117,104,'1',1.26,4),(4,'NBA','Philadelphia 76ers','Los Angeles Lakers',143,120,'1',1.34,3.35),(5,'NBA','Dallas Mavericks','Portland Trail Blazers',102,101,'1',1.74,2.15),(6,'NBA','Milwaukee Bucks','Orlando Magic',83,103,'2',1.12,6.5),(7,'NBA','Houston Rockets','Oklahoma City Thunder',112,117,'2',1.8,2.05),(8,'NBA','Boston Celtics','Los Angeles Clippers',112,123,'2',1.11,6.75),(9,'NBA','Chicago Bulls','Washington Wizards',125,134,'2',2,1.83),(10,'NBA','Memphis Grizzlies','New Orleans Pelicans',99,90,'1',1.8,2.05),(11,'NBA','Atlanta Hawks','Charlotte Hornets',120,129,'2',2.2,1.71),(12,'NBA','New York Knicks','Toronto Raptors',99,104,'2',5.25,1.18),(13,'NBA','Indiana Pacers','Cleveland Cavaliers',105,90,'1',1.05,11),(14,'NBA','Utah Jazz','San Antonio Spurs',125,105,'1',1.4,3.05),(15,'NBA','Sacramento Kings','Miami Heat',102,96,'1',1.68,2.25),(16,'NBA','New Orleans Pelicans','Minnesota Timberwolves',122,117,'1',1.44,2.85),(17,'NBA','Phoenix Suns','Golden State Warriors',107,117,'2',9,1.07),(18,'NBA','Dallas Mavericks','Milwaukee Bucks',107,122,'2',3.9,1.27),(19,'NBA','Brooklyn Nets','Chicago Bulls',106,125,'2',1.25,4.2),(20,'NBA','Detroit Pistons','New York Knicks',120,103,'1',1.26,4),(21,'NBA','Philadelphia 76ers','Denver Nuggets',117,110,'1',1.5,2.7),(22,'NBA','Washington Wizards','Cleveland Cavaliers',119,106,'1',1.16,5.5),(23,'NBA','Portland Trail Blazers','San Antonio Spurs',127,118,'1',1.45,2.8),(24,'NBA','Boston Celtics','Los Angeles Lakers',128,129,'2',1.32,3.5),(25,'NBA','Oklahoma City Thunder','Memphis Grizzlies',117,95,'1',1.05,11),(26,'NBA','Atlanta Hawks','Toronto Raptors',101,119,'2',4.25,1.23),(27,'NBA','Indiana Pacers','Los Angeles Clippers',116,92,'1',1.44,2.85);
/*!40000 ALTER TABLE `basket` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-29 14:25:12
